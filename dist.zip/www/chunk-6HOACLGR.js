import{b as a,c as b}from"./chunk-JWIEPCRG.js";import"./chunk-RW4GY4BD.js";export{a as GESTURE_CONTROLLER,b as createGesture};
